Currently only some OO patterns for C#, VB, native C++ and C++\CLI are implemented, 
but eventually more languages and patterns will follow.
Uninstall previous versions of the add-in from the Windows start menu: 
'All Programs'->'Design Patterns'->'Uninstall DesignPatterns for VS 20XX'
Download the archive, unzip it, and look for the the folder(s) corresponding 
to the same Visual Studio version(s) you are using.
Close Visual Studio and run the the setup.exe from the corresponding folder.
So far, I have tested it only on Windows 7 64 bit and Windows XP 32 bit.
If you see errors when Visual Studio starts, from the its respective VS command prompt run 
"devenv /resetaddin *" command.Also a 'Reset Add-in' menu in the 
Start\DesignPatterns\Uninstall Design Patterns for 20XX is provided in case for some reason 
this add-in does not show up in the menus and the 'Manage Add-ins' Visual Studio menu.
If no menu entry with "Design Patterns..." show up in Visual Studio, or if the first
time you invoke the add-in won't load correctly, from the Windows start menu, click on
the DesignPatterns\VS20XX\Reset Add-in menu.
To change the code or the templates, you must first install the specific add-in, 
build once in debug mode and then uninstall the add-in from the start menu.
More details about creating and changing templates are available at 
http://www.codeproject.com/Articles/767200/Visual-Studio-Design-Patterns-add-in.